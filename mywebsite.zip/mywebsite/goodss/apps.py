from django.apps import AppConfig


class GoodssConfig(AppConfig):
    name = 'goodss'
